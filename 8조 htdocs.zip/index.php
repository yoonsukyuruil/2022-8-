
<?php
    include("db.php");
?>
<html>
	<head>
		<style>
 /* DivTable */
 .divTable{
	display: table;
	width: 100%;
    float:middle;
    margin:auto;
}
.divTableBody {
	display: table-row-group;
}
.divTableRow {
	display: table-row;
}
.divTableCell {
	border: 1px solid #999999;
	display: table-cell;
	padding: 30px 10px;
}
.divTableCell_api {
	border: 1px solid #999999;
	display: table-cell;
	padding: 30px 10px;
}  
body {
	background-image:url("img/bg.jpg"),url("img/bg(1).jpg");   /* 배경 이미지 : 앞에 있는거만 적용됨*/
  	text-align : center; /* 글자 중앙 맞춤 */
	background-size:contain; /* 배경 이미지 조절 */
	 background-repeat: no-repeat ;/* 배경이미지 반복하는거 없애기  */
} 
		</style>
		<title>DIYP Project</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body onLoad="proc()">
    <!-- 비트코인============================================= -->
 <script src="https://code.jquery.com/jquery-1.4.4.min.js"></script>	
	<!--  background="img/bg.jpg" bgcolor=#FFFFFF-->
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header">
						<div class="logo">
							DIYP <span class="icon fa-Diamond"></span>
						</div>
						<div class="content">
							<div class="inner">
								<div class="search">
									
								<form action="https://search.naver.com/search.naver">
            <div class="search">
                <input type="text" name="query" value="" placeholder="검색어 입력">
            </div>
        </form>
</div>
	<div id = t_full>
        <div class="divTable" style="width: 100%">
            <div class="divTableBody">
                <div class="divTableRow">
                    <div class="divTableCell">
                        <a href="http://www.naver.com" style=text-decoration: none;>
						<img src="img/download2.jpg" width="50px" height="50px" ></a> 
                    </div>
                    <div class="divTableCell">
                        <a href="http://www.google.com" title="구글">
                            <img src="img/download4.png" width="50px" height="50px" >
                        </a>
                    </div>
                    <div class="divTableCell">
                        <a href="http://www.daum.net" title="다음">
                            <img src="img/download3.png" width="50px" height="50px" >
                        </a>
                    </div>
                    <div class="divTableCell">
                        <a href="http://www.youtube.com" title="유튜브">
                            <img src="img/download.png" width="50px" height="50px" >
                        </a>
                    </div>
                </div>
                <div class="divTableRow">
		
                    <div class="divTableCell">&nbsp;
					<a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoia28ifQ%3D%3D%22%7D" title="트위터">
                            <img src="img/d5.png" width="50px" height="50px" >
					</a> 
					</div>
                    <div class="divTableCell">&nbsp;
					<a href="https://www.netflix.com/kr/" title="넷플릭스">
                            <img src="img/download6.png" width="50px" height="50px" >
                        </a>
					</div>
                    <div class="divTableCell">&nbsp;
					<a href="https://www.instagram.com" title="인스타">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
					</div>
                    <div class="divTableCell">&nbsp;
					<a href="developing.php" title="개발중입니다">
                            <img src="img/download8.png" width="50px" height="50px" >
                        </a>
					</div>
                </div>
            </div>
        </div>  
    </div> <br>
						<a href="https://papago.naver.com/" title="파파고">
                            <img src="img/api1.png" width="50px" height="50px" >
                        </a>
						<a href="api2.php" title="비트코인 API">
                            <img src="img/api2.png" width="50px" height="50px" >
                        </a>
						<a href="https://map.naver.com/v5/?c=14115613.4868934,4506003.3526663,15,0,0,0,dh" title="네이버지도">
                            <img src="img/download5.png" width="50px" height="50px" >
                        </a>
						<a href="https://bus.go.kr/searchResult6.jsp" title="버스 도착정보">
                            <img src="img/api3.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.weather.go.kr/w/index.do" title="기상청 날씨 정보">
                            <img src="img/api4.png" width="50px" height="50px" >
                        </a>
						<a href="sample.php" title="책 검색 API">
                            <img src="img/api5.png" width="50px" height="50px" >
                        </a>
						<a href="api6.php" title="미세먼지 API">
                            <img src="img/api6.png" width="50px" height="50px" >
                        </a>

					
							</div>
						</div>
						<nav>
							
							<ul>
								
								<li><a href="register.php">회원가입</a></li>
								<li><a href="login.php">로그인</a></li>
								<!--<li><a href="#elements">Elements</a></li>-->
							</ul>
						</nav>
					</header>

			</div>
		<!-- BG -->
			<div id="bg"></div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
