<?php
$db_host = "127.0.0.1";
$db_user = "root";
$db_passwd ="1234";
$db_name = "test";
$conn = mysqli_connect($db_host, $db_user, $db_passwd, $db_name);

?>
