<?php
	include "db.php";
	include "password.php";


	//POST로 받아온 아이다와 비밀번호가 비었다면 알림창을 띄우고 전 페이지로 돌아갑니다.
	if($_POST["userid"] == "" || $_POST["userpw"] == ""){
		echo '<script> alert("아이디나 패스워드를 입력하세요"); history.back(); </script>';
	}else if ($_POST["username"] == "" || $_POST["adress"] == ""){
		echo '<script> alert("이름과 주소를 입력하세요"); history.back(); </script>';
	}else if ($_POST["sex"] == "" || $_POST["email"] == ""){
			echo '<script> alert("상별과 이메일을 입력하세요"); history.back(); </script>';
	}else
	$userid = $_POST['userid'];
	$userpw = password_hash($_POST['userpw'], PASSWORD_DEFAULT);
	$username = $_POST['name'];
	$adress = $_POST['adress'];
	$sex = $_POST['sex'];
	$email = $_POST['email'].'@'.$_POST['emadress'];

$sql = mq("insert into member (id,pw,name,adress,sex,email) values('".$userid."','".$userpw."','".$username."','".$adress."','".$sex."','".$email."')");

?>
<meta charset="utf-8" />
<script type="text/javascript">alert('회원가입이 완료되었습니다.');</script>
<meta http-equiv="refresh" content="0 url=/">