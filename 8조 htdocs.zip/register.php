<?php  
include "db.php";
?>
    <html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>회원가입</title>
        <link rel="stylesheet" href="tabledesign.css" />
        <style>
            body {
                margin: 0;
            }



            .btn1 {
                position: relative;
                right: 0px;
                bottom: -10px;
                border: none;
                box-shadow: none;
                width: 130px;
                height: 40px;
                line-height: 42px;
                -webkit-perspective: 230px;
                perspective: 230px;
            }

            .btn1 span {
                background: rgb(115, 104, 93);
                background: linear-gradient(0deg, rgba(115, 104, 93, 1) 0%, rgba(115, 104, 93, 1) 100%);
                display: block;
                position: absolute;
                width: 130px;
                height: 40px;
                box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5),
                    7px 7px 20px 0px rgba(0, 0, 0, .1),
                    4px 4px 5px 0px rgba(0, 0, 0, .1);
                border-radius: 5px;
                margin: 0;
                text-align: center;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                -webkit-transition: all .3s;
                transition: all .3s;
            }

            .btn1 span:nth-child(1) {
                box-shadow:
                    -7px -7px 20px 0px #fff9,
                    -4px -4px 5px 0px #fff9,
                    7px 7px 20px 0px #0002,
                    4px 4px 5px 0px #0001;
                -webkit-transform: rotateX(90deg);
                -moz-transform: rotateX(90deg);
                transform: rotateX(90deg);
                -webkit-transform-origin: 50% 50% -20px;
                -moz-transform-origin: 50% 50% -20px;
                transform-origin: 50% 50% -20px;
            }

            .btn1 span:nth-child(2) {
                -webkit-transform: rotateX(0deg);
                -moz-transform: rotateX(0deg);
                transform: rotateX(0deg);
                -webkit-transform-origin: 50% 50% -20px;
                -moz-transform-origin: 50% 50% -20px;
                transform-origin: 50% 50% -20px;
            }

            .btn1:hover span:nth-child(1) {
                box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5),
                    7px 7px 20px 0px rgba(0, 0, 0, .1),
                    4px 4px 5px 0px rgba(0, 0, 0, .1);
                -webkit-transform: rotateX(0deg);
                -moz-transform: rotateX(0deg);
                transform: rotateX(0deg);
            }

            .btn1:hover span:nth-child(2) {
                box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5),
                    7px 7px 20px 0px rgba(0, 0, 0, .1),
                    4px 4px 5px 0px rgba(0, 0, 0, .1);
                color: transparent;
                -webkit-transform: rotateX(-90deg);
                -moz-transform: rotateX(-90deg);
                transform: rotateX(-90deg);
            }



            .btn2 {
                position: relative;
                right: -10px;
                bottom: -10px;
                border: none;
                box-shadow: none;
                width: 130px;
                height: 40px;
                line-height: 42px;
                -webkit-perspective: 230px;
                perspective: 230px;
            }

            .btn2 span {
                background: rgb(115, 104, 93);
                background: linear-gradient(0deg, rgba(115, 104, 93, 1) 0%, rgba(115, 104, 93, 1) 100%);
                display: block;
                position: absolute;
                width: 130px;
                height: 40px;
                box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5),
                    7px 7px 20px 0px rgba(0, 0, 0, .1),
                    4px 4px 5px 0px rgba(0, 0, 0, .1);
                border-radius: 5px;
                margin: 0;
                text-align: center;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                -webkit-transition: all .3s;
                transition: all .3s;
            }

            .btn2 span:nth-child(1) {
                box-shadow:
                    -7px -7px 20px 0px #fff9,
                    -4px -4px 5px 0px #fff9,
                    7px 7px 20px 0px #0002,
                    4px 4px 5px 0px #0001;
                -webkit-transform: rotateX(90deg);
                -moz-transform: rotateX(90deg);
                transform: rotateX(90deg);
                -webkit-transform-origin: 50% 50% -20px;
                -moz-transform-origin: 50% 50% -20px;
                transform-origin: 50% 50% -20px;
            }

            .btn2 span:nth-child(2) {
                -webkit-transform: rotateX(0deg);
                -moz-transform: rotateX(0deg);
                transform: rotateX(0deg);
                -webkit-transform-origin: 50% 50% -20px;
                -moz-transform-origin: 50% 50% -20px;
                transform-origin: 50% 50% -20px;
            }

            .btn2:hover span:nth-child(1) {
                box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5),
                    7px 7px 20px 0px rgba(0, 0, 0, .1),
                    4px 4px 5px 0px rgba(0, 0, 0, .1);
                -webkit-transform: rotateX(0deg);
                -moz-transform: rotateX(0deg);
                transform: rotateX(0deg);
            }

            .btn2:hover span:nth-child(2) {
                box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5),
                    7px 7px 20px 0px rgba(0, 0, 0, .1),
                    4px 4px 5px 0px rgba(0, 0, 0, .1);
                color: transparent;
                -webkit-transform: rotateX(-90deg);
                -moz-transform: rotateX(-90deg);
                transform: rotateX(-90deg);
            }
        </style>
    </head>

    <body>

        <form method="post" action="member_ok.php">
            <div class="bg">
                <br>
                <br>
                <br>
                <table style="margin-left: auto; margin-right: auto;" border="1" height="500">
                    <tr>
                        <th>아이디</th>
                        <td><input type="text" size="35" name="userid" placeholder="아이디"></td>
                    </tr>
                    <tr>
                        <th>비밀번호</th>
                        <td><input type="password" size="35" name="userpw" placeholder="비밀번호"></td>
                    </tr>
                    <tr>
                        <th>이름</th>
                        <td><input type="text" size="35" name="name" placeholder="이름"></td>
                    </tr>
                    <tr>
                        <th>주소</th>
                        <td><input type="text" size="35" name="adress" placeholder="주소"></td>
                    </tr>
                    <tr>
                        <th>성별</th>
                        <td>남<input type="radio" name="sex" value="남"> 여<input type="radio" name="sex" value="여"></td>
                    </tr>
                    <tr>
                        <th>이메일</th>
                        <td><input type="text" name="email">@<select name="emadress">
                                <option value="naver.com">naver.com</option>
                                <option value="nate.com">nate.com</option>
                                <option value="hanmail.com">hanmail.com</option>
                                <option value="gmail.com">gmail.com</option>
                                <option value="kakao.com">kakao.com</option>
                            </select></td>
                    </tr>
                </table>


                <div class="find-btn">
                <button style="font-weight: bold; 
                background-color:transparent;
                    color: #fff;" type="submit" class="btn1"><span>클릭!</span><span>가입하기</span></button>
                <button style="font-weight: bold;
                background-color:transparent;
                    color: #fff;" type="reset" class="btn2"><span>클릭!</span><span>다시쓰기</span></button>
                    </div>
            </div>

        </form>
    </body>

    </html>