<?php

?>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bookdesign.css" />
    <title>도서 검색</title>
</head>


<body>

    <br><br><br><br>
    <div class="bookpage">
    <br>
    <table style="margin-left: auto; margin-right: auto;" border="1">
        <tr>
            <td>도서 검색</td>
            <td><input id="bookName" value="" type="text">
                <button id="search">검색</button>
            </td>
        </tr>
    </table>
    <br>

    
        <p id="bookinfo1" align="center"> </p>
        <p id="bookinfo2" align="center"> </p>
        <p id="bookinfo3" align="center"> </p>
        <p id="bookinfo4" align="center"> </p>

        <script src="https://code.jquery.com/jquery-3.6.1.js"
            integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
        <script>
            $(document).ready(function () {
                $("#search").click(function () {
                    $.ajax({
                        method: "GET",
                        url: "https://dapi.kakao.com/v3/search/book?target=title",
                        data: { query: $("#bookName").val() },
                        headers: { Authorization: "KakaoAK 439dcf59b55311ad04615c028fc49881" },
                        success: function (response) {
                            $("#bookinfo1").empty();
                            $("#bookinfo2").empty();
                            $("#bookinfo3").empty();
                            $("#bookinfo4").empty();
                        }

                    })
                        .done(function (msg) {
                            console.log(msg.documents[0].title);
                            console.log(msg.documents[0].price);
                            console.log(msg.documents[0].thumbnail);
                            console.log(msg.documents[0].contents);

                            $("#bookinfo1").append("<img src='" + msg.documents[0].thumbnail + "'/><br><br>");
                            $("#bookinfo2").append("제목: " + "<strong>" + msg.documents[0].title + "</strong><br><br>");
                            $("#bookinfo3").append("소개: " + "<strong>" + msg.documents[0].contents + "</strong><br><br>");
                            $("#bookinfo4").append("가격: " + "<strong>" + msg.documents[0].price + "원" + "</strong><br><br>");



                        });


                });
            });
        </script>

    </div>
</body>

</html>