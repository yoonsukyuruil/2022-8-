<meta charset="utf-8" />
<?php	
    include "db.php";
	include "password.php";
echo "<script>alert('개발 중입니다.'); 
history.back();</script>"
?>