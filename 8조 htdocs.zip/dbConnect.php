<?php
    $host = 'localhost';
    $user = 'root';
    $passWord = '1234';
    $dbName = 'myservice';

    $dbConnect = new mysqli($host,$user,$passWord,$dbName);
?>