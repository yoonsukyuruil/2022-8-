<?php   include "db.php"; ?>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DIYP login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="로긴디자인.css" />
    


    
</head>
<body>
    <body>
        <div id="login">
            <br>
            <div class="container">
                <div id="login-row" class="row justify-content-center align-items-center">
                    <div id="login-column" class="col-md-6">
                        <div id="login-box" class="col-md-12">
                            <form id="login-form" class="form" action="login_ok.php" method="post">
                                <h3 class="text-center text-info text-black">로그인</h3>
                                <div class="my_div my_bg" style= "float:right;">
                                </div>
                                <div class="form-group">
                                    <label for="userid" class="text-info text-black">아이디:</label><br>
                                    <input type="text" name="userid" id="userid" class="inph">
                                </div>
                                <div class="form-group">
                                    <label for="password" class="text-info text-black">비밀번호:</label><br>
                                    <input type="password" name="userpw" id="password" class="inph">
                                </div>
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
                                <br>
                                <br>
								<br>
                                <div style= float: left; width: 50%;>
                                    <label for="remember-me" class="text-info text-black"><span>아이디 기억</span><span><input id="remember-me" name="remember-me" type="checkbox"></span></label>
                                &nbsp&nbsp
                                    <a href="register.php" class="text-info text-black">회원가입</a>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>

</body>
</html>