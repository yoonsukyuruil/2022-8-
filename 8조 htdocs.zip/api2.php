<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DIYP</title>
</head>
<style>
    table {border-collapse: collapse}
    td, th {padding:5px; width:120px}

    .modal-header{
                background: #0e4f1f; /*초록색*/
                color: white;
            }

            .modal-body{
                background: white; 
            }

            .modal-footer{
                background: #0e4f1f;
            }
            /* close 버튼 */
            .button{
                margin:auto;
                padding: 15px 15px;
                text-align: center;
                border-color: black; 
                cursor:pointer;
                font: sans-serif;
                font-weight : 500 ;
                width: 100px;
            }

</style>
    
<!-- 비트코인 -->
<script>
            // 전역 변수 세팅
            var usd = 0;
            var alert_array = new Array();
            
            // 천단위 콤마 함수
            function numberWithCommas(x) {
                return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
            // 숫자 외 문자열 제거 함수
            function numberDeleteChar(x) {
                return x.toString().replace(/[^0-9]+/g, '');
            }
            
            // 빗썸 함수 
            function bithumb(){
                $.get('https://api.bithumb.com/public/ticker/ALL', function(data) {
                    var bithumb_btc = parseFloat(data['data']['BTC']['closing_price']);
                    var bithumb_eth = parseFloat(data['data']['ETH']['closing_price']);
                    var bithumb_xrp = parseFloat(data['data']['XRP']['closing_price']);
                    $('#bithumb_BTC').html('\\ ' + numberWithCommas(bithumb_btc)); // 거래소 시세 정보 표에 값 세팅
                    $('#bithumb_ETH').html('\\ ' + numberWithCommas(bithumb_eth));
                    $('#bithumb_XRP').html('\\ ' + numberWithCommas(bithumb_xrp));
                });
            }
                    
            // 알람 세팅 함수
            function alert_setting() {
                var selectTrade = $("#targetTrade option:selected").val(); // 선택된 거래소
                var selectAmount = numberDeleteChar($("#targetAmount").val()); // 선택된 시세
                var targetIf = $("#targetIf option:selected").val(); // 이상/이하
                var tmp_array = new Array(selectTrade, selectAmount, targetIf); // 세팅 값 3개를 묶음
                alert_array.push(tmp_array); // 세팅 값 저장
                if(targetIf == '0')
                    var targetIfPrint = "<font color='blue'>이하</font>";
                else if(targetIf == '1')
                    var targetIfPrint = "<font color='red'>이상</font>";
                $("#alert_list").append("<li><b>"+selectTrade+"</b> 거래소의 시세가 <b>"+numberWithCommas(selectAmount)+"</b> 원 "+targetIfPrint+" 일 때 알람</li>")
            }
            
            // 알람 실행 함수
            function alert_start() {
                // 알람 배열 크기만큼 순회
                for(var i=0; i < alert_array.length; i++) {
                    if(typeof alert_array[i]=='undefined') continue; // 지워진 알람이면 건너뛰기
                    var selectTrade = alert_array[i][0];
                    var selectAmount = alert_array[i][1];
                    var targetIf = alert_array[i][2];
                    var currentAmount = numberDeleteChar($('#'+selectTrade).html()); // 거래소의 현재 시세
                    var d = new Date();
                    
                    if(targetIf == '0' && parseFloat(currentAmount) <= parseFloat(selectAmount)) { // 거래소의 현재 시세가 설정 값보다 이하일때
                        alert(selectTrade + " 거래소의 시세가 " + selectAmount + "원 이하(" + currentAmount + ")입니다.\n" + d.toString());
                        delete(alert_array[i]); // 알람 세팅 값 삭제
                    } else if(targetIf == '1' && parseFloat(currentAmount) >= parseFloat(selectAmount)) { // 거래소의 현재 시세가 설정 값보다 이상일때
                        alert(selectTrade + " 거래소의 시세가 " + selectAmount + "원 이상(" + currentAmount + ")입니다.\n" + d.toString());
                        delete(alert_array[i]); // 알람 세팅 값 삭제
                    }
                }
                
                // 알람목록 갱신
                $("#alert_list").empty();
                for(var i=0; i < alert_array.length; i++) {
                    if(typeof alert_array[i]=='undefined') continue; // 지워진 알람이면 건너뛰기
                    var selectTrade = alert_array[i][0];
                    var selectAmount = alert_array[i][1];
                    var targetIf = alert_array[i][2];
                    if(targetIf == '0') var targetIfPrint = "<font color='blue'>이하</font>";
                    else if(targetIf == '1') var targetIfPrint = "<font color='red'>이상</font>";
                    $("#alert_list").append("<li><b>"+selectTrade+"</b> 거래소의 시세가 <b>"+numberWithCommas(selectAmount)+"</b> 원 "+targetIfPrint+" 일 때 알람</li>")
                }
                
            }
            

            // 현재 시간 갱신
            function CurrentTime() {
                var d = new Date();
                $("#lastUpdate").html(d.toString());
            }
            
            // 갱신 함수
            function proc() {
                try {
                    bithumb(); // 빗썸
                    alert_start(); // 알람 확인
                    CurrentTime(); // 갱신 시간
                } catch(e){
                    
                } finally {
                    setTimeout("proc()", 10000); //10초후 재시작
                }
            }
        </script>
<body onLoad="proc()">
    <!-- 비트코인============================================= -->
 <script src="https://code.jquery.com/jquery-1.4.4.min.js"></script>
<!-- <a href="myModal" data-toggle="modal" data-target="#myModal_coin"><input type="button" value="코인"></a> -->

<div class="modal" id="myModal_coin" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h1 class="modal-title" id="exampleModalLongTitle">비트코인 api </h1>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <!-- 환율 정보 -->
        <span id="USDKRW"></span>
        
        <!-- 거래소 시세 정보 -->
        <table border=1 width="100%">
            <tr>
                <th></th>
                <th>빗썸</th>
            </tr>
            <tr>
                <td>비트코인</td>
                <td id="bithumb_BTC"></td>
            </tr>
            <tr>
                <td>이더리움</td>
                <td id="bithumb_ETH"></td>
            </tr>
            <tr>
                <td>리플</td>
                <td id="bithumb_XRP"></td>
            </tr>
            <tr>
                <td>최근 갱신 시간</td>
                <td colspan="4" id="lastUpdate"></td>
            </tr>
        </table>
<!-- 알람 설정 -->
        <select id="targetTrade">
            <option value="bithumb_BTC">빗썸 비트코인</option>
            <option value="bithumb_ETH">빗썸 이더리움</option>
            <option value="bithumb_XRP">빗썸 리플</option>
        </select> 이
        <input id="targetAmount" type="text" value="100"> 원
        <select id="targetIf">
            <option value="1">이상</option>
            <option value="0">이하</option>
        </select> 일때 알람
        <input id="targetSetting" type="button" value="설정" onClick="alert_setting()">
        
        <!-- 알람 목록 -->
        <ul id="alert_list"></ul
        </div>
        
        <!-- Modal footer -->
        <!-- Modal footer -->
        <div class="modal-footer">
           <center><button type="button" class="button" data-dismiss="modal" onclick="history.go(-1)">back</button></center>
        </div>

      </div>
    </div>
</div>
</div>

</body>
</html>