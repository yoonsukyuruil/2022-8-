<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DIYP</title>
</head>
<style>
    .button{ /* 버튼*/
                margin:auto;
                padding: 15px 15px;
                text-align: center;
                border-color: black;
                cursor:pointer;
                font: sans-serif;
                font-weight : 500 ;
                width: 100px;
            }

            .modal-header{
                background: #0e4f1f; /*초록색*/
                color: white;
                
            }

            .modal-body{
                background: white; 
                
            }

            .modal-footer{
                background: #0e4f1f;
            }

</style>
<!-- 미세먼지 -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
 
<body >
   
<!-- 미세먼지=============================================-->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- <a href="myModal" data-toggle="modal" data-target="#myModal"><input type="button" value="미세먼지"></a> -->
 
<!-- <div class="modal" id="myModal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-xl modal-dialog-centered">
      <div class="modal-content">
      
         Modal Header -->
        <div class="modal-header"> 
          <h4 class="modal-title">미세먼지 api</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <div class = "modal-body">
        <center><img src="img/seoul.png" width="468px" height=auto ></center>
        </div>



    <script>
        function q1() {
            $.ajax({
                type: "GET",
                url: "http://openapi.seoul.go.kr:8088/6d4d776b466c656533356a4b4b5872/json/RealtimeCityAir/1/99",
                data: {},
                success: function (response) {
                    $("#names-q1").empty(); 
                    let mise = response["RealtimeCityAir"]["row"]; 
                    for (let i = 0; i < mise.length; i++) {  
                        let gu_name = mise[i]["MSRSTE_NM"];
                        let gu_mise = mise[i]["IDEX_MVL"];
                        if (gu_mise > 1) { 
                            let str_mise = `<li>${gu_name} : ${gu_mise}pm</li>`; 
                            $("#names-q1").append(str_mise); 

                        }
                    }
                    console.log(response)
                }
            })
        }
    </script>
        </div>
        <div class = "modal-body">
        <div class="question-box" border:3px solid#878787>        
        <center><button class= "button" onclick="q1()" >업데이트 </button> </cesnter>
         <ul id="names-q1"  > <!--style="text-align:center;" -->
        </ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
        <button type="button" class="button" data-dismiss="modal" onclick="history.go(-1)">back</button>
        </div>
     </div>
      </div>
    </div>
</div>

</body>
</html>