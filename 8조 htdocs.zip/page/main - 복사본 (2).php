
<?php
    include("db.php");
?>
<html>
	<head>
		<style>
 /* DivTable */
 .divTable{
	display: table;
	width: 100%;
    float:middle;
    margin:auto;
}
.divTableBody {
	display: table-row-group;
}
.divTableRow {
	display: table-row;
}
.divTableCell {
	border: 1px solid #999999;
	display: table-cell;
	padding: 30px 10px;
}
.divTableCell_api {
	border: 1px solid #999999;
	display: table-cell;
	padding: 30px 10px;
}
<style type="image/css"> 
a { image-decoration:none } 
		</style>
		<title>DIYP Project</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<center><br><br><br><br>
<table class="tg">

  <thead>
    <tr>
      <th class="tg-huad"><center>어서오세요! <?php echo $login_session; ?> 님</th>
    </tr>
  </thead>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header">
						<div class="logo">
							DIYP <span class="icon fa-Diamond"></span>
						</div>
						<div class="content">
							<div class="inner">
								<div class="search">
     <input type="text" placeholder="검색어를 입력해주세요." width="100%">
			</div>
				<br>


								<div id = t_full>
        <div class="divTable" style="width: 100%">
            <div class="divTableBody">
                <div class="divTableRow">
                    <div class="divTableCell">
                        <a href="http://www.naver.com" style=text-decoration: none;>
						<img src="img/download2.jpg" width="50px" height="50px" ></a> 
                        
                    </div>
                    <div class="divTableCell">
                        <a href="http://www.google.com" title="구글">
                            <img src="img/download4.png" width="50px" height="50px" >
                        </a>
                    </div>
                    <div class="divTableCell">
                        <a href="http://www.daum.net" title="다음">
                            <img src="img/download3.png" width="50px" height="50px" >
                        </a>
                    </div>
                    <div class="divTableCell">
                        <a href="http://www.youtube.com" title="유튜브">
                            <img src="img/download.png" width="50px" height="50px" >
                        </a>
                    </div>
                </div>
        
                <div class="divTableRow">
		
                    <div class="divTableCell">&nbsp;
					<a href="https://map.naver.com/v5/?c=14115613.4868934,4506003.3526663,15,0,0,0,dh" title="네이버 지도">
                            <img src="img/download5.png" width="50px" height="50px" >
					</a> 
					</div>
                    <div class="divTableCell">&nbsp;
					<a href="https://www.netflix.com/kr/" title="넷플릭스">
                            <img src="img/download6.png" width="50px" height="50px" >
                        </a>
					</div>

                    <div class="divTableCell">&nbsp;
					<a href="https://www.instagram.com" title="인스타">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
					</div>
                    <div class="divTableCell">&nbsp;
					<a href="index.php",title="개발중">
                            <img src="img/download8.png" width="50px" height="50px" >
                        </a>

					</div>
                </div>
            </div>
        </div>  
    </div> <br>
						<a href="https://www.instagram.com" title="API1">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.instagram.com" title="API2">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.instagram.com" title="API3">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.instagram.com" title="API4">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.instagram.com" title="API5">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.instagram.com" title="API6">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>
						<a href="https://www.instagram.com" title="API7">
                            <img src="img/download7.png" width="50px" height="50px" >
                        </a>


						
							</div>
						</div>
						<nav>
							
							<ul>
								
								<li><a href="logout.php">로그아웃</a></li>
								<li><a href="setting.php">설정</a></li>
								<!--<li><a href="#elements">Elements</a></li>-->
							</ul>
						</nav>
					</header>

				<!-- Main -->
					<div id="main">

						<!-- Intro -->
							<article id="intro">
								<h2 class="major">Intro</h2>
								<span class="image main"><img src="img/pic01.jpg" alt="" /></span>
								<p>Aenean ornare velit lacus, ac varius enim ullamcorper eu. Proin aliquam facilisis ante interdum congue. Integer mollis, nisl amet convallis, porttitor magna ullamcorper, amet egestas mauris. Ut magna finibus nisi nec lacinia. Nam maximus erat id euismod egestas. By the way, check out my <a href="#work">awesome work</a>.</p>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis dapibus rutrum facilisis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Etiam tristique libero eu nibh porttitor fermentum. Nullam venenatis erat id vehicula viverra. Nunc ultrices eros ut ultricies condimentum. Mauris risus lacus, blandit sit amet venenatis non, bibendum vitae dolor. Nunc lorem mauris, fringilla in aliquam at, euismod in lectus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In non lorem sit amet elit placerat maximus. Pellentesque aliquam maximus risus, vel sed vehicula.</p>
							</article>

						<!-- Work -->
							<article id="work">
								<h2 class="major">Work</h2>
								<span class="image main"><img src="img/pic02.jpg" alt="" /></span>
								<p>Adipiscing magna sed dolor elit. Praesent eleifend dignissim arcu, at eleifend sapien imperdiet ac. Aliquam erat volutpat. Praesent urna nisi, fringila lorem et vehicula lacinia quam. Integer sollicitudin mauris nec lorem luctus ultrices.</p>
								<p>Nullam et orci eu lorem consequat tincidunt vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus pharetra. Pellentesque condimentum sem. In efficitur ligula tate urna. Maecenas laoreet massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus amet feugiat tempus.</p>
							</article>

						<!-- About -->
							<article id="about">
								<h2 class="major">About</h2>
								<span class="image main"><img src="img/pic03.jpg" alt="" /></span>
								<p>Lorem ipsum dolor sit amet, consectetur et adipiscing elit. Praesent eleifend dignissim arcu, at eleifend sapien imperdiet ac. Aliquam erat volutpat. Praesent urna nisi, fringila lorem et vehicula lacinia quam. Integer sollicitudin mauris nec lorem luctus ultrices. Aliquam libero et malesuada fames ac ante ipsum primis in faucibus. Cras viverra ligula sit amet ex mollis mattis lorem ipsum dolor sit amet.</p>
							</article>

					</div>

				<!-- Footer -->
					

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
